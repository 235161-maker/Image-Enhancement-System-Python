import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk
import numpy as np
import os
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as ReportImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import io

from image_processor import ImageProcessor

class ImageEnhancementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DIP Image Enhancement System")
        self.root.geometry("1400x800")
        self.root.configure(bg='#2c3e50')
        
        self.processor = ImageProcessor()
        self.current_image = None
        self.image_history = []
        
        self.setup_ui()
        
    def setup_ui(self):
        # Create main container
        main_container = tk.Frame(self.root, bg='#2c3e50')
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Top frame for title
        title_frame = tk.Frame(main_container, bg='#34495e', height=60)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, text="Digital Image Processing - Image Enhancement System", 
                              font=('Arial', 20, 'bold'), bg='#34495e', fg='white')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(main_container, bg='#2c3e50')
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left panel for controls
        left_panel = tk.Frame(content_frame, bg='#ecf0f1', width=350)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_panel.pack_propagate(False)
        
        # Right panel for display
        right_panel = tk.Frame(content_frame, bg='#2c3e50')
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Create notebook for tabs in left panel
        notebook = ttk.Notebook(left_panel)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Image Loading
        load_frame = ttk.Frame(notebook)
        notebook.add(load_frame, text="Load Image")
        self.setup_load_tab(load_frame)
        
        # Tab 2: Sampling & Quantization
        sampling_frame = ttk.Frame(notebook)
        notebook.add(sampling_frame, text="Sampling & Quantization")
        self.setup_sampling_tab(sampling_frame)
        
        # Tab 3: Transformations
        transform_frame = ttk.Frame(notebook)
        notebook.add(transform_frame, text="Transformations")
        self.setup_transform_tab(transform_frame)
        
        # Tab 4: Intensity & Histogram
        intensity_frame = ttk.Frame(notebook)
        notebook.add(intensity_frame, text="Intensity & Histogram")
        self.setup_intensity_tab(intensity_frame)
        
        # Tab 5: Enhancement Pipeline
        enhance_frame = ttk.Frame(notebook)
        notebook.add(enhance_frame, text="Enhancement Pipeline")
        self.setup_enhance_tab(enhance_frame)
        
        # Right panel - Image display area
        display_frame = tk.Frame(right_panel, bg='white', relief=tk.RAISED, borderwidth=2)
        display_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.image_label = tk.Label(display_frame, bg='white', text="No Image Loaded", 
                                    font=('Arial', 14), fg='gray')
        self.image_label.pack(expand=True)
        
        # Info panel
        info_frame = tk.Frame(right_panel, bg='#34495e', height=150)
        info_frame.pack(fill=tk.X, pady=(5, 0))
        info_frame.pack_propagate(False)
        
        self.info_text = ScrolledText(info_frame, height=8, font=('Courier', 9))
        self.info_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Button frame
        button_frame = tk.Frame(right_panel, bg='#2c3e50', height=40)
        button_frame.pack(fill=tk.X, pady=(5, 0))
        
        tk.Button(button_frame, text="Generate Report", command=self.generate_report,
                 bg='#27ae60', fg='white', font=('Arial', 10, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Save Output", command=self.save_output,
                 bg='#3498db', fg='white', font=('Arial', 10, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Reset", command=self.reset_all,
                 bg='#e74c3c', fg='white', font=('Arial', 10, 'bold')).pack(side=tk.LEFT, padx=5)
        
    def setup_load_tab(self, parent):
        # Load image section
        load_btn = tk.Button(parent, text="Load Image", command=self.load_image,
                            bg='#3498db', fg='white', font=('Arial', 12, 'bold'),
                            height=2, width=20)
        load_btn.pack(pady=20)
        
        # Image info frame
        info_frame = tk.LabelFrame(parent, text="Image Information", font=('Arial', 10, 'bold'))
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.resolution_label = tk.Label(info_frame, text="Resolution: -", font=('Arial', 9))
        self.resolution_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.channels_label = tk.Label(info_frame, text="Channels: -", font=('Arial', 9))
        self.channels_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.dtype_label = tk.Label(info_frame, text="Data Type: -", font=('Arial', 9))
        self.dtype_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.size_label = tk.Label(info_frame, text="File Size: -", font=('Arial', 9))
        self.size_label.pack(anchor=tk.W, padx=5, pady=2)
        
    def setup_sampling_tab(self, parent):
        # Resampling
        resample_frame = tk.LabelFrame(parent, text="Resampling", font=('Arial', 10, 'bold'))
        resample_frame.pack(fill=tk.X, padx=10, pady=5)
        
        scales = [0.25, 0.5, 1.0, 1.5, 2.0]
        for scale in scales:
            btn = tk.Button(resample_frame, text=f"{scale}x Scale", 
                           command=lambda s=scale: self.apply_resampling(s),
                           bg='#95a5a6', width=15)
            btn.pack(pady=2)
        
        # Quantization
        quant_frame = tk.LabelFrame(parent, text="Bit Depth Reduction", font=('Arial', 10, 'bold'))
        quant_frame.pack(fill=tk.X, padx=10, pady=5)
        
        bits = [8, 4, 2]
        for bit in bits:
            btn = tk.Button(quant_frame, text=f"{bit}-bit", 
                           command=lambda b=bit: self.apply_quantization(b),
                           bg='#95a5a6', width=15)
            btn.pack(pady=2)
            
    def setup_transform_tab(self, parent):
        # Rotation
        rot_frame = tk.LabelFrame(parent, text="Rotation", font=('Arial', 10, 'bold'))
        rot_frame.pack(fill=tk.X, padx=10, pady=5)
        
        angles = [30, 45, 60, 90, 120, 150, 180]
        for angle in angles:
            btn = tk.Button(rot_frame, text=f"{angle}°", 
                           command=lambda a=angle: self.apply_rotation(a),
                           bg='#95a5a6', width=10)
            btn.pack(side=tk.LEFT, padx=2, pady=2)
        
        # Translation
        trans_frame = tk.LabelFrame(parent, text="Translation", font=('Arial', 10, 'bold'))
        trans_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(trans_frame, text="Left", command=lambda: self.apply_translation(-50, 0),
                 bg='#95a5a6', width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(trans_frame, text="Right", command=lambda: self.apply_translation(50, 0),
                 bg='#95a5a6', width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(trans_frame, text="Up", command=lambda: self.apply_translation(0, -50),
                 bg='#95a5a6', width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(trans_frame, text="Down", command=lambda: self.apply_translation(0, 50),
                 bg='#95a5a6', width=8).pack(side=tk.LEFT, padx=2)
        
        # Shearing
        shear_frame = tk.LabelFrame(parent, text="Shearing", font=('Arial', 10, 'bold'))
        shear_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(shear_frame, text="Shear X", command=lambda: self.apply_shearing(0.3),
                 bg='#95a5a6', width=10).pack(side=tk.LEFT, padx=2)
        tk.Button(shear_frame, text="Shear Y", command=lambda: self.apply_shearing(0.5),
                 bg='#95a5a6', width=10).pack(side=tk.LEFT, padx=2)
        
        # Reset button
        tk.Button(parent, text="Reset to Original", command=self.reset_to_original,
                 bg='#e74c3c', fg='white', font=('Arial', 10, 'bold'),
                 height=2, width=20).pack(pady=10)
        
    def setup_intensity_tab(self, parent):
        # Intensity transformations
        intensity_frame = tk.LabelFrame(parent, text="Intensity Transformations", font=('Arial', 10, 'bold'))
        intensity_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(intensity_frame, text="Negative", command=self.apply_negative,
                 bg='#9b59b6', fg='white', width=15).pack(pady=2)
        tk.Button(intensity_frame, text="Log Transform", command=self.apply_log,
                 bg='#9b59b6', fg='white', width=15).pack(pady=2)
        tk.Button(intensity_frame, text="Gamma (γ=0.5)", command=lambda: self.apply_gamma(0.5),
                 bg='#9b59b6', fg='white', width=15).pack(pady=2)
        tk.Button(intensity_frame, text="Gamma (γ=1.5)", command=lambda: self.apply_gamma(1.5),
                 bg='#9b59b6', fg='white', width=15).pack(pady=2)
        
        # Histogram processing
        hist_frame = tk.LabelFrame(parent, text="Histogram Processing", font=('Arial', 10, 'bold'))
        hist_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        tk.Button(hist_frame, text="Show Histogram", command=self.show_histogram,
                 bg='#e67e22', fg='white', width=15).pack(pady=2)
        tk.Button(hist_frame, text="Histogram Equalization", command=self.apply_equalization,
                 bg='#e67e22', fg='white', width=15).pack(pady=2)
        
    def setup_enhance_tab(self, parent):
        info_text = tk.Text(parent, height=10, wrap=tk.WORD, font=('Arial', 9))
        info_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        info_text.insert(1.0, """Complete Enhancement Pipeline:

1. Convert to Grayscale
2. Gamma Correction (γ=1.2) - Adjust brightness
3. Histogram Equalization - Enhance contrast
4. Log Transform - Highlight details

This pipeline automatically enhances low-quality images by:
- Improving brightness distribution
- Enhancing contrast
- Revealing hidden details
- Normalizing intensity levels""")
        info_text.config(state=tk.DISABLED)
        
        tk.Button(parent, text="Run Complete Enhancement", command=self.run_enhancement,
                 bg='#27ae60', fg='white', font=('Arial', 12, 'bold'),
                 height=2, width=25).pack(pady=20)
        
    def load_image(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
        )
        if file_path:
            try:
                self.processor.load_image(file_path)
                self.processor.convert_to_grayscale()
                self.current_image = self.processor.grayscale_image
                self.display_image(self.current_image)
                self.update_image_info()
                messagebox.showinfo("Success", "Image loaded successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load image: {str(e)}")
    
    def display_image(self, image):
        if image is not None:
            # Convert to PIL Image
            if len(image.shape) == 2:
                pil_image = Image.fromarray(image)
            else:
                pil_image = Image.fromarray(image)
            
            # Resize for display
            display_size = (600, 450)
            pil_image.thumbnail(display_size, Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(pil_image)
            self.image_label.config(image=photo, text="")
            self.image_label.image = photo
    
    def update_image_info(self):
        info = self.processor.get_image_info()
        if info:
            self.resolution_label.config(text=f"Resolution: {info['resolution']}")
            self.channels_label.config(text=f"Channels: {info['channels']}")
            self.dtype_label.config(text=f"Data Type: {info['data_type']}")
            self.size_label.config(text=f"File Size: {info['file_size']}")
            
            # Update info text
            self.info_text.delete(1.0, tk.END)
            self.info_text.insert(1.0, f"Image Analysis Report\n")
            self.info_text.insert(tk.END, f"{'='*50}\n")
            self.info_text.insert(tk.END, f"Resolution: {info['resolution']}\n")
            self.info_text.insert(tk.END, f"Channels: {info['channels']}\n")
            self.info_text.insert(tk.END, f"Data Type: {info['data_type']}\n")
            self.info_text.insert(tk.END, f"File Size: {info['file_size']}\n")
    
    def apply_resampling(self, scale):
        if self.processor.grayscale_image is not None:
            resampled = self.processor.resample_image(scale)
            self.current_image = resampled
            self.display_image(resampled)
            self.info_text.insert(tk.END, f"\nApplied {scale}x resampling\n")
            self.info_text.see(tk.END)
    
    def apply_quantization(self, bits):
        if self.processor.grayscale_image is not None:
            quantized = self.processor.reduce_bit_depth(bits)
            self.current_image = quantized
            self.display_image(quantized)
            self.info_text.insert(tk.END, f"\nReduced bit depth to {bits}-bit (256->{2**bits} levels)\n")
            self.info_text.see(tk.END)
    
    def apply_rotation(self, angle):
        if self.processor.grayscale_image is not None:
            rotated = self.processor.rotate_image(angle)
            self.current_image = rotated
            self.display_image(rotated)
            self.info_text.insert(tk.END, f"\nRotated by {angle} degrees\n")
            self.info_text.see(tk.END)
    
    def apply_translation(self, x, y):
        if self.processor.grayscale_image is not None:
            translated = self.processor.translate_image(x, y)
            self.current_image = translated
            self.display_image(translated)
            self.info_text.insert(tk.END, f"\nTranslated by ({x}, {y}) pixels\n")
            self.info_text.see(tk.END)
    
    def apply_shearing(self, shear):
        if self.processor.grayscale_image is not None:
            sheared = self.processor.shear_image(shear)
            self.current_image = sheared
            self.display_image(sheared)
            self.info_text.insert(tk.END, f"\nSheared with factor {shear}\n")
            self.info_text.see(tk.END)
    
    def apply_negative(self):
        if self.current_image is not None:
            negative = self.processor.negative_transform(self.current_image)
            self.current_image = negative
            self.display_image(negative)
            self.info_text.insert(tk.END, "\nApplied negative transformation\n")
            self.info_text.see(tk.END)
    
    def apply_log(self):
        if self.current_image is not None:
            log_transformed = self.processor.log_transform(self.current_image)
            self.current_image = log_transformed
            self.display_image(log_transformed)
            self.info_text.insert(tk.END, "\nApplied log transformation\n")
            self.info_text.see(tk.END)
    
    def apply_gamma(self, gamma):
        if self.current_image is not None:
            gamma_corrected = self.processor.gamma_correction(gamma, self.current_image)
            self.current_image = gamma_corrected
            self.display_image(gamma_corrected)
            self.info_text.insert(tk.END, f"\nApplied gamma correction (γ={gamma})\n")
            self.info_text.see(tk.END)
    
    def apply_equalization(self):
        if self.current_image is not None:
            equalized = self.processor.histogram_equalization(self.current_image)
            self.current_image = equalized
            self.display_image(equalized)
            self.info_text.insert(tk.END, "\nApplied histogram equalization\n")
            self.info_text.see(tk.END)
    
    def show_histogram(self):
        if self.current_image is not None:
            fig = Figure(figsize=(8, 6))
            ax = fig.add_subplot(111)
            
            histogram = self.processor.compute_histogram(self.current_image)
            ax.plot(histogram, color='black')
            ax.set_xlabel('Pixel Intensity')
            ax.set_ylabel('Frequency')
            ax.set_title('Image Histogram')
            ax.grid(True, alpha=0.3)
            
            # Create new window for histogram
            hist_window = tk.Toplevel(self.root)
            hist_window.title("Histogram Analysis")
            hist_window.geometry("800x600")
            
            canvas = FigureCanvasTkAgg(fig, master=hist_window)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def run_enhancement(self):
        if self.processor.grayscale_image is not None:
            enhanced = self.processor.enhance_image()
            self.current_image = enhanced
            self.display_image(enhanced)
            
            # Show comparison
            fig, axes = plt.subplots(1, 3, figsize=(12, 4))
            axes[0].imshow(self.processor.grayscale_image, cmap='gray')
            axes[0].set_title('Original')
            axes[0].axis('off')
            
            axes[1].imshow(enhanced, cmap='gray')
            axes[1].set_title('Enhanced')
            axes[1].axis('off')
            
            # Show histograms
            hist_orig = self.processor.compute_histogram(self.processor.grayscale_image)
            hist_enh = self.processor.compute_histogram(enhanced)
            
            axes[2].plot(hist_orig, label='Original', alpha=0.7)
            axes[2].plot(hist_enh, label='Enhanced', alpha=0.7)
            axes[2].set_title('Histogram Comparison')
            axes[2].legend()
            axes[2].grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.show()
            
            self.info_text.insert(tk.END, "\n" + "="*50 + "\n")
            self.info_text.insert(tk.END, "COMPLETE ENHANCEMENT PIPELINE EXECUTED\n")
            self.info_text.insert(tk.END, "Steps Applied:\n")
            self.info_text.insert(tk.END, "1. Gamma Correction (γ=1.2)\n")
            self.info_text.insert(tk.END, "2. Histogram Equalization\n")
            self.info_text.insert(tk.END, "3. Log Transform\n")
            self.info_text.insert(tk.END, "="*50 + "\n")
            self.info_text.see(tk.END)
    
    def reset_to_original(self):
        if self.processor.grayscale_image is not None:
            self.current_image = self.processor.grayscale_image
            self.display_image(self.current_image)
            self.info_text.insert(tk.END, "\nReset to original grayscale image\n")
            self.info_text.see(tk.END)
    
    def reset_all(self):
        self.current_image = None
        self.image_label.config(image='', text="No Image Loaded")
        self.info_text.delete(1.0, tk.END)
        self.resolution_label.config(text="Resolution: -")
        self.channels_label.config(text="Channels: -")
        self.dtype_label.config(text="Data Type: -")
        self.size_label.config(text="File Size: -")
    
    def save_output(self):
        if self.current_image is not None:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg")]
            )
            if file_path:
                self.processor.save_image(self.current_image, file_path)
                messagebox.showinfo("Success", f"Image saved to {file_path}")
    
    def generate_report(self):
        if self.current_image is not None:
            report_path = f"results/report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            os.makedirs("results", exist_ok=True)
            
            doc = SimpleDocTemplate(report_path, pagesize=letter)
            styles = getSampleStyleSheet()
            story = []
            
            # Title
            title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=16, spaceAfter=30)
            story.append(Paragraph("Digital Image Processing - Image Enhancement System Report", title_style))
            story.append(Spacer(1, 12))
            
            # Student Info
            story.append(Paragraph("Student Information:", styles['Heading2']))
            story.append(Paragraph("Name: [Your Name]", styles['Normal']))
            story.append(Paragraph("Registration ID: [Your Reg ID]", styles['Normal']))
            story.append(Spacer(1, 12))
            
            # Image Info
            info = self.processor.get_image_info()
            if info:
                story.append(Paragraph("Original Image Information:", styles['Heading2']))
                story.append(Paragraph(f"Resolution: {info['resolution']}", styles['Normal']))
                story.append(Paragraph(f"Channels: {info['channels']}", styles['Normal']))
                story.append(Paragraph(f"Data Type: {info['data_type']}", styles['Normal']))
                story.append(Spacer(1, 12))
            
            # Q&A Section
            story.append(Paragraph("Questions & Answers:", styles['Heading2']))
            
            qa_pairs = [
                ("1. Why does histogram equalization improve contrast?",
                 "Histogram equalization improves contrast by spreading out the most frequent intensity values across the entire intensity range. This redistributes the pixel intensities to make the image's histogram more uniform, thereby enhancing the contrast where the image's histogram is concentrated."),
                
                ("2. How does gamma affect brightness?",
                 "Gamma correction controls brightness non-linearly. γ < 1 makes dark regions brighter (expands shadow details), while γ > 1 makes bright regions darker (compresses highlights). γ = 1 gives linear response. Lower gamma values brighten the image, higher values darken it."),
                
                ("3. What is the effect of quantization on image quality?",
                 "Quantization reduces image quality by decreasing the number of distinct intensity levels. Lower bit depth (e.g., 2-bit) causes false contours and posterization effects, where smooth gradients appear as distinct bands. 8-bit gives 256 levels (good quality), 4-bit gives 16 levels (noticeable degradation), 2-bit gives 4 levels (severe degradation)."),
                
                ("4. Which transformation is reversible and why?",
                 "Geometric transformations like rotation, translation, and shearing are reversible if we know the transformation parameters. However, they may lose information at edges. Intensity transformations like gamma and log are not truly reversible because they map multiple input values to same output values."),
                
                ("5. How do transformations affect spatial structure?",
                 "Geometric transformations change the spatial arrangement of pixels by moving them to new coordinates, potentially causing aliasing or interpolation artifacts. Intensity transformations modify pixel values but preserve spatial relationships. Both types maintain overall image structure but geometric ones alter positions while intensity ones alter values.")
            ]
            
            for q, a in qa_pairs:
                story.append(Paragraph(q, styles['Heading3']))
                story.append(Paragraph(a, styles['Normal']))
                story.append(Spacer(1, 6))
            
            # Build PDF
            doc.build(story)
            messagebox.showinfo("Success", f"Report generated: {report_path}")

def main():
    root = tk.Tk()
    app = ImageEnhancementApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()