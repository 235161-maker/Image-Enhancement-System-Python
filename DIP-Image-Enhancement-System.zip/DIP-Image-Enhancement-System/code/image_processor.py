import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg
from PIL import Image
import io

class ImageProcessor:
    def __init__(self):
        self.original_image = None
        self.grayscale_image = None
        self.processed_image = None
        self.history = []
        
    def load_image(self, image_path):
        """Load image from path"""
        self.original_image = cv2.imread(image_path)
        if self.original_image is None:
            raise ValueError("Could not load image")
        self.original_image = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2RGB)
        return self.original_image
    
    def convert_to_grayscale(self):
        """Convert RGB to Grayscale"""
        if self.original_image is not None:
            self.grayscale_image = cv2.cvtColor(self.original_image, cv2.COLOR_RGB2GRAY)
            return self.grayscale_image
        return None
    
    def get_image_info(self):
        """Get image information"""
        if self.original_image is not None:
            height, width = self.original_image.shape[:2]
            channels = self.original_image.shape[2] if len(self.original_image.shape) > 2 else 1
            dtype = self.original_image.dtype
            return {
                'resolution': f"{width} x {height}",
                'channels': channels,
                'data_type': str(dtype),
                'file_size': f"{width * height * channels / 1024:.2f} KB"
            }
        return None
    
    def resample_image(self, scale):
        """Resample image by scaling factor"""
        if self.grayscale_image is not None:
            new_height = int(self.grayscale_image.shape[0] * scale)
            new_width = int(self.grayscale_image.shape[1] * scale)
            resampled = cv2.resize(self.grayscale_image, (new_width, new_height), 
                                   interpolation=cv2.INTER_LINEAR)
            return resampled
        return None
    
    def reduce_bit_depth(self, bits):
        """Reduce image bit depth"""
        if self.grayscale_image is not None:
            levels = 2 ** bits
            scaled = self.grayscale_image / 255.0
            quantized = np.floor(scaled * (levels - 1)) / (levels - 1)
            return (quantized * 255).astype(np.uint8)
        return None
    
    def rotate_image(self, angle):
        """Rotate image by angle"""
        if self.grayscale_image is not None:
            height, width = self.grayscale_image.shape[:2]
            center = (width // 2, height // 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(self.grayscale_image, rotation_matrix, (width, height))
            return rotated
        return None
    
    def translate_image(self, x, y):
        """Translate image"""
        if self.grayscale_image is not None:
            translation_matrix = np.float32([[1, 0, x], [0, 1, y]])
            translated = cv2.warpAffine(self.grayscale_image, translation_matrix, 
                                        (self.grayscale_image.shape[1], self.grayscale_image.shape[0]))
            return translated
        return None
    
    def shear_image(self, shear_factor):
        """Shear image"""
        if self.grayscale_image is not None:
            height, width = self.grayscale_image.shape[:2]
            shear_matrix = np.float32([[1, shear_factor, 0], [0, 1, 0]])
            sheared = cv2.warpAffine(self.grayscale_image, shear_matrix, 
                                    (int(width + abs(shear_factor) * height), height))
            return sheared
        return None
    
    def negative_transform(self, image=None):
        """Apply negative transformation"""
        img = image if image is not None else self.grayscale_image
        if img is not None:
            return 255 - img
        return None
    
    def log_transform(self, image=None, c=1):
        """Apply log transformation"""
        img = image if image is not None else self.grayscale_image
        if img is not None:
            img_float = img.astype(np.float32)
            log_transformed = c * np.log1p(img_float)
            log_transformed = (log_transformed / log_transformed.max() * 255).astype(np.uint8)
            return log_transformed
        return None
    
    def gamma_correction(self, gamma, image=None):
        """Apply gamma correction"""
        img = image if image is not None else self.grayscale_image
        if img is not None:
            img_float = img.astype(np.float32) / 255.0
            gamma_corrected = np.power(img_float, gamma)
            gamma_corrected = (gamma_corrected * 255).astype(np.uint8)
            return gamma_corrected
        return None
    
    def histogram_equalization(self, image=None):
        """Apply histogram equalization"""
        img = image if image is not None else self.grayscale_image
        if img is not None:
            equalized = cv2.equalizeHist(img)
            return equalized
        return None
    
    def compute_histogram(self, image=None):
        """Compute image histogram"""
        img = image if image is not None else self.grayscale_image
        if img is not None:
            histogram = cv2.calcHist([img], [0], None, [256], [0, 256])
            return histogram
        return None
    
    def enhance_image(self):
        """Complete enhancement pipeline"""
        if self.grayscale_image is None:
            return None
        
        # Step 1: Apply gamma correction for brightness adjustment
        gamma_corrected = self.gamma_correction(1.2)
        
        # Step 2: Apply histogram equalization for contrast enhancement
        equalized = self.histogram_equalization(gamma_corrected)
        
        # Step 3: Apply slight log transform for detail enhancement
        enhanced = self.log_transform(equalized, c=0.8)
        
        self.processed_image = enhanced
        return enhanced
    
    def save_image(self, image, path):
        """Save image to path"""
        cv2.imwrite(path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))