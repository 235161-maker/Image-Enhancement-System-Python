#!/usr/bin/env python3
"""
Digital Image Processing - Image Enhancement System
Complete implementation with GUI interface
"""

import sys
import os

# Add code directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui_app import main

if __name__ == "__main__":
    print("Starting DIP Image Enhancement System...")
    print("Please ensure you have installed required packages: pip install -r requirements.txt")
    main()